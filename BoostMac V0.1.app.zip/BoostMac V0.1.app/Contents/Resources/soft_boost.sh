#!/bin/bash

# BoostMac: Unified cleanup with visible progress

# Ask for admin password once up front
sudo -v

# Silent cleanup block in background
(
  echo "🧹 Clearing caches..."
  rm -rf ~/Library/Caches/*

  echo "💡 Flushing DNS..."
  sudo dscacheutil -flushcache
  sudo killall -HUP mDNSResponder

  echo "🧠 Freeing RAM..."
  sudo purge
) &

# Simple unified progress bar
echo -n "Boosting Mac: ["
for i in {1..60}; do
  echo -n "█"
  sleep 0.1
done
echo "]"

echo "✅ Boost complete!"
